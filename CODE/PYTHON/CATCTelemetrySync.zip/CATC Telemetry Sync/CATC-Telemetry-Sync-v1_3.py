####################################
# project:  CATC-License-Sync
# author:   kebaldwi@cisco.com
# use case: Synchronize Telemetry
# version:  1.3
####################################

from dnacentersdk import api
import json

# Configuration
CCip = "10.10.0.20" #"your_cc_ip"  # Replace with your actual CC IP
CCuser = "admin" #"your_username"  # Replace with your actual username
CCpwd = "Ghter+_)(" #"your_password"  # Replace with your actual password

# Initialize the SDK
dnac = api.DNACenterAPI(base_url=f"https://{CCip}",username=CCuser,password=CCpwd,verify=False)

# Function to get the inventory of devices
def get_inventory():
    response = dnac.devices.get_device_list()
    return response['response']

# Function to synchronize device licenses in batches
def sync_device_telemetry(device_ids):
    url = f"https://{CCip}/api/v1/scheduled-job"

    # Process one device at a time
    for i in range(0, len(device_ids)):
        batch_string = device_ids[i]
        payload = [{"description":"Update Telemetry Settings Task","startTime":-1,"timeZone":"","referenceSchedId":None,"referenceTaskId":None,"externalSchedule":{"notificationHeader":{"Content-Type":"application/json","Preview-Prime-Mode":True},"notificationURL":"/api/v1/deploysettings/FORCE_PUSH","notificationBody":[batch_string],"notificationMethod":"POST","module":"DEVICE_CONTROLLABILITY_AND_TELEMETRY"},"paramNamesAndValues":{"deployRBAC":"{\"network.group\":\"gRead\",\"network.customer-facing-service\":\"gUpdate\",\"network.provision.devicecontrollability.telemetry\":\"gUpdate\"}","timeZoneAwareness":True,"vcrEnabled":True}}]
        response = dnac._session.post(url, json=payload)
    return

# Main execution
def main():
    try:
        # Step 1: Get the inventory of devices
        devices = get_inventory()
        
        # Step 2: Filter devices based on criteria
        device_ids = []
        for device in devices:
            family = device.get("family", "")
            reachable = device.get("reachabilityStatus", "")
            if reachable == "Reachable" and "Unified AP" not in family:
                device_ids.append(device["id"])
        
        # Step 3: Synchronize device telemetry
        sync_device_telemetry(device_ids)
        
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
