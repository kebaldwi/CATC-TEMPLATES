####################################
# project:  CATC-License-Sync
# author:   kebaldwi@cisco.com
# use case: Synchronize Licensing
# version:  1.3
####################################

from dnacentersdk import api
import json

# Configuration
CCip = "your_cc_ip"  # Replace with your actual CC IP
CCuser = "your_username"  # Replace with your actual username
CCpwd = "your_password"  # Replace with your actual password

# Initialize the SDK
dnac = api.DNACenterAPI(base_url=f"https://{CCip}",username=CCuser,password=CCpwd,verify=False)

# Function to get the inventory of devices
def get_inventory():
    response = dnac.devices.get_device_list()
    return response['response']

# Function to get the licensing status (smart and virtual account IDs)
def get_licensing_status():
    url = f"https://{CCip}/dna/system/api/v1/license/status"
    response = dnac._session.get(url)
    return response['response']

# Function to synchronize device licenses in batches
def sync_device_license(virtual_account_id, smart_account_id, device_ids):
    url = f"https://{CCip}/api/v1/licensemanager/slenhancements/reportusage"
    
    # Check if batching is necessary
    if len(device_ids) > 50:
        # Batch the device IDs
        for i in range(0, len(device_ids), 50):
            batch = device_ids[i:i + 50]
            payload = {
                "vaCSSMId": virtual_account_id,
                "smartAccountId": smart_account_id,
                "device_uuids": ",".join(batch)  # Join UUIDs into a single string
            }
            
            response = dnac._session.post(url, json=payload)
            if response.status_code == 200:
                print(f"Successfully synchronized batch: {batch}")
            else:
                print(f"Failed to synchronize batch: {batch}. Error: {response.text}")
    else:
        # Send all device IDs in a single request
        payload = {
            "vaCSSMId": virtual_account_id,
            "smartAccountId": smart_account_id,
            "device_uuids": ",".join(device_ids)  # Join UUIDs into a single string
        }
        response = dnac._session.post(url, json=payload)
        '''if response.status_code == 200:
            print(f"Successfully synchronized all devices: {device_ids}")
        else:
            print(f"Failed to synchronize all devices: {device_ids}. Error: {response.text}")'''

# Main execution
def main():
    try:
        # Step 1: Get the inventory of devices
        devices = get_inventory()
        
        # Step 2: Filter devices based on criteria
        device_ids = []
        for device in devices:
            family = device.get("family", "")
            reachable = device.get("reachabilityStatus", "")
            if reachable == "Reachable" and "Unified AP" not in family:
                device_ids.append(device["id"])
        
        # Step 3: Get smart and virtual account IDs
        licensing_info = get_licensing_status()
        virtual_account_id = licensing_info.get("virtualAccountId", "default_virtual_account_id")  # Adjust as necessary
        smart_account_id = licensing_info.get("smartAccountId", "default_smart_account_id")  # Adjust as necessary

        # Step 4: Synchronize device licenses
        sync_device_license(virtual_account_id, smart_account_id, device_ids)
        
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
